package com.virtusa.payroll.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.virtusa.payroll.service.DBUtils;
import com.virtusa.payroll.sql.SqlQuery;



public class MBODAO 
{
	public static float getMBO(int year,String quarter,int eid)
	{
		
		float mbo=0;
		String query = null;
		if(quarter.equals("mbo1"))
		{
			query = SqlQuery.mbo1_query;
		}
		else if(quarter.equals("mbo2"))
		{
			query = SqlQuery.mbo2_query;;
		}
		else if(quarter.equals("mbo3"))
		{
			query =SqlQuery.mbo3_query;;
		}
		else
		{
			query = SqlQuery.mbo4_query;;
		}
		try 
		{
			Connection con = DBUtils.buildConnection();
			
			PreparedStatement ps = con.prepareStatement(query);
			ps.setInt(1, eid);
			ps.setInt(2, year);
			ResultSet res = ps.executeQuery();
			int count=0;
			while(res.next())
			{
				
			mbo= res.getFloat(1);
			}
		}catch(Exception e)
		{
			e.printStackTrace();
		}
	
	return mbo;
		
	}
	
	public static Date MBOPayout(int empid)
	{
		Date date=null;
		try {
			String date_query = SqlQuery.date_query;
			Connection con = DBUtils.buildConnection();
			PreparedStatement ps = con.prepareStatement(date_query);
			ps.setInt(1,empid);
			ResultSet res = ps.executeQuery();
			while(res.next()){
					date=res.getDate(1);
			}
			}
		catch(Exception e) {
			System.out.println(e);
		}
return date;
}
}
