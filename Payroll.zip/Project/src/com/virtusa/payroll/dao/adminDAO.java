package com.virtusa.payroll.dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.virtusa.payroll.models.Login;
import com.virtusa.payroll.service.DBUtils;
import com.virtusa.payroll.sql.SqlQuery;

public class adminDAO {
	
	public static void deleteEmployee(int id)
	{
		String delemp=SqlQuery.delemp;
		String deladd=SqlQuery.deladd;
		String delsal=SqlQuery.delsal;
		String dellog=SqlQuery.dellog;
		String delpwd=SqlQuery.delpwd;

		
		try {
			Connection con=DBUtils.buildConnection();

			PreparedStatement p1=con.prepareStatement(deladd);
			p1.setInt(1, id);
			p1.executeUpdate();
			System.out.println("Address details deleted");
			PreparedStatement p2=con.prepareStatement(delsal);
			p2.setInt(1, id);
			p2.executeUpdate();
			System.out.println("Salary details deleted");
			PreparedStatement p3=con.prepareStatement(delemp);
			p3.setInt(1, id);
			p3.executeUpdate();
			System.out.println("Employee details deleted");
			PreparedStatement p5=con.prepareStatement(delpwd);
			p5.setInt(1, id);
			p5.executeUpdate();
			System.out.println("Forgot_password details deleted");
			PreparedStatement p4=con.prepareStatement(dellog);
			p4.setInt(1, id);
			p4.executeUpdate();
			System.out.println("Login details deleted");
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public static Login createEmployee(int id)
	{

		PreparedStatement ps=null;
		String admin_login=SqlQuery.admin_login;
		int idInDb=0;
		String pwdInDb="";
		Login login=null;
		Connection con=DBUtils.buildConnection();
		try {
			 ps=con.prepareStatement(admin_login);
			ps.setInt(1, id);
			ResultSet rs=ps.executeQuery();
			while(rs.next())
			{
				idInDb=rs.getInt(1);
				System.out.println(idInDb);
				pwdInDb=rs.getString(3);
				System.out.println(pwdInDb);
				login=new Login(idInDb,pwdInDb);
			}
			} 
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return login;
		
	}
	public static int userEntry(int emp_id,String emp_name,String email_id,String address,int city_id,int state_id,String pincode,String contact_number,String joining_date,int hr_id,int dept_id,int manager_id,int experience)
	{
		String empquery=SqlQuery.empquery;
		String addquery=SqlQuery.addquery;
		Connection con=DBUtils.buildConnection();
		System.out.println(con);
		 PreparedStatement st;
		 int val=0,val1=0;
		
		try {
			st = con.prepareStatement(empquery);
			 st.setInt(1, emp_id);
			 st.setString(2, emp_name);
			 st.setString(3, email_id);
			 st.setString(4, contact_number);
			 st.setString(5, joining_date);
			 st.setInt(6,hr_id);
			 st.setInt(7, dept_id);
			 st.setInt(8, manager_id);
			 st.setInt(9, experience);
			 val=st.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println(val);
		 
		if(val>0)
		{
			try {
				PreparedStatement ps;
				ps=con.prepareStatement(addquery);
				ps.setString(1, address);
				 ps.setInt(2, city_id);
				 ps.setInt(3, state_id);
				 ps.setString(4, pincode);
				 ps.setInt(5,emp_id);
				 val1=ps.executeUpdate();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		System.out.println(val1);
		return val1;
	}
	

}
