package com.virtusa.payroll.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.virtusa.payroll.models.Salary;
import com.virtusa.payroll.service.DBUtils;
import com.virtusa.payroll.sql.SqlQuery;


public class SalaryDAO {
	
	public static Salary getSalary(int id,String month,int year)
	{
		String query=SqlQuery.salary_query;
		Connection con=DBUtils.buildConnection();
		//ArrayList<Salary> al=new ArrayList<Salary>();
		int salary_id,designation_id,emp_id;
		float pf,allowance,insurance,per_hour_salary,hours_worked;
		
		Salary salary=null;
		try {
			PreparedStatement st=con.prepareStatement(query);
			st.setInt(1, id);
			st.setInt(2, year);
			st.setString(3, month);
			ResultSet rs=st.executeQuery();
			while(rs.next())
			{
				salary_id=rs.getInt(1);
				designation_id=rs.getInt(2);
				emp_id=rs.getInt(3);
				pf=rs.getFloat(4);
				allowance=rs.getFloat(5);
				insurance=rs.getFloat(6);
				per_hour_salary=rs.getFloat(7);
				hours_worked=rs.getFloat(8);
				
				 salary=new Salary(salary_id,designation_id,emp_id,pf,allowance,insurance,per_hour_salary,hours_worked);
				 System.out.println(salary);
				
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return salary;
		
	}

}
