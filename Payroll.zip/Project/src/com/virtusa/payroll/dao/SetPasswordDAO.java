package com.virtusa.payroll.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.virtusa.payroll.controller.SetPassword;
import com.virtusa.payroll.service.DBUtils;
import com.virtusa.payroll.sql.SqlQuery;

public class SetPasswordDAO
{
	private static String query3;
	public static String getPassword(String newPassword,int empid)
	{
		
			String passwordInDB=null;
		try 
		{
			Connection conn = DBUtils.buildConnection();
			String query1 = SqlQuery.query1;
			PreparedStatement ps = conn.prepareStatement(query1);
			ps.setInt(1, empid);
			ResultSet rs = ps.executeQuery();
	         while(rs.next())
	         {
		          passwordInDB=rs.getString(1);
	         }
			
		}
			catch(Exception e)  
			{
				e.printStackTrace();
			}
	
		return passwordInDB;
}
	public static int updatePassword(String newPassword,int empid)
	{
		int res =0;
		Connection conn = DBUtils.buildConnection();
		String query2 =SqlQuery.query2;
   	 PreparedStatement pst1;
	try {
		pst1 = conn.prepareStatement(query2);
		pst1.setString(1, newPassword);
        pst1.setInt(2, empid);
         res = pst1.executeUpdate();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	return res;
        
	}
}
