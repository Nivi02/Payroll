package com.virtusa.payroll.dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.virtusa.payroll.service.DBUtils;
import com.virtusa.payroll.sql.SqlQuery;

public class ChangeDAO {

	public static void setEmailDetailsIfNotEmpty(String email,int empid)
	{
		Connection  con=DBUtils.buildConnection();
		String sql=SqlQuery.sql;
    	PreparedStatement ps=null;
		try {
			ps = con.prepareStatement(sql);
			ps.setString(1, email);
	    	ps.setInt(2,empid);
	        ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
   	}
	public static String setEmailDetailsIfEmpty(int empid){
		Connection  con=DBUtils.buildConnection();
	
		String email_query=SqlQuery.email_query;
        PreparedStatement ps2;
        String emailid=null;

		try {
			 ps2 = con.prepareStatement(email_query);
			 ps2.setInt(1,empid);
		        ResultSet rs2=ps2.executeQuery();
		        while(rs2.next()) {
		        	emailid=rs2.getString(1);
		        	//System.out.println(emailid);
		        }
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
       return emailid;
	}
	
	public static void setContactDetailsIfNotEmpty(String mobile,int empid)
	{
		Connection  con=DBUtils.buildConnection();
		String sql1=SqlQuery.sql1;
    	PreparedStatement ps1;
		try {
			ps1 = con.prepareStatement(sql1);
			ps1.setString(1, mobile);
	    	ps1.setInt(2,empid);
	        ps1.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
	}
	public static String setContactDetailsIfEmpty(int empid)
	{
		Connection  con=DBUtils.buildConnection();
		String contactno_query=SqlQuery.contactno_query;
        PreparedStatement ps4;
        String contact_no=null;

		try {
			ps4 = con.prepareStatement(contactno_query);
			 ps4.setInt(1,empid);
		        ResultSet rs4=ps4.executeQuery();
		        while(rs4.next()) {
		        	contact_no=rs4.getString(1);
		        }
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		return contact_no;
	}
	public static void setAddressDetailsIfNotEmpty(String address,int empid)
	{
		Connection  con=DBUtils.buildConnection();
		PreparedStatement ps2=null;
		String sql2=SqlQuery.sql2;
		try {
			ps2=con.prepareStatement(sql2);
	    	ps2.setString(1, address);
	    	ps2.setInt(2,empid);
	        ps2.executeUpdate();	
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public static String setAddressDetailsIfEmpty(int empid)
	{
		Connection  con=DBUtils.buildConnection();
		String address_query=SqlQuery.address_query;
        PreparedStatement ps5;
        String address_detail=null;
		try {
			ps5 = con.prepareStatement(address_query);
			 ps5.setInt(1,empid);
		        ResultSet rs5=ps5.executeQuery();
		        while(rs5.next()) {
		        	address_detail=rs5.getString(1);
		        }
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
       return address_detail; 
	}
		
}
