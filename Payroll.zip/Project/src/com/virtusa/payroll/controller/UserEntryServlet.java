package com.virtusa.payroll.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.virtusa.payroll.dao.adminDAO;
import com.virtusa.payroll.service.DBUtils;


/**
 * Servlet implementation class UserEntryServlet
 */
@WebServlet("/UserEntryServlet")
public class UserEntryServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

   	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
				
		int emp_id=Integer.parseInt(request.getParameter("id"));
		String emp_name=request.getParameter("name");
		String email_id=request.getParameter("eid");
		String address=request.getParameter("address");
		int city_id=Integer.parseInt(request.getParameter("cid"));
		int state_id=Integer.parseInt(request.getParameter("sid"));
		String pincode=request.getParameter("pincode");
		String contact_number=request.getParameter("contact");
		String joining_date=request.getParameter("date");
		int hr_id=Integer.parseInt(request.getParameter("hr_id"));
		int dept_id=Integer.parseInt(request.getParameter("dept_id"));
		int manager_id=Integer.parseInt(request.getParameter("manager_id"));
		int experience=Integer.parseInt(request.getParameter("exp"));
		
			
			int val1=adminDAO.userEntry(emp_id,emp_name,email_id,address,city_id,state_id,pincode,contact_number,joining_date,hr_id,dept_id,manager_id,experience);
			
		if(val1>0)
		{
		out.println("\nSuccessfullyRegistered");
		RequestDispatcher rd=request.getRequestDispatcher("/Link.html");
		rd.include(request, response);
		}
		else
		{
			out.println("Enter the data");
			RequestDispatcher rd=request.getRequestDispatcher("/userEntry.html");
			rd.include(request, response);
		}
	}

}
