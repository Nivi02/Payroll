package com.virtusa.payroll.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.virtusa.payroll.dao.LoginDAO;

/**
 * Servlet implementation class Validate
 */
@WebServlet("/Validate")
public class Validate extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		RequestDispatcher dispatcher = null;
		
		HttpSession session = request.getSession(false);
		int empid = (int) session.getAttribute("eid");
		String answerinDB=LoginDAO.validateAnswer(empid);
		String ans = request.getParameter("ans");
		
		
	if(ans.equals(answerinDB) ) {
		System.out.println("if");
		dispatcher = request.getRequestDispatcher("password.html");
		dispatcher.include(request, response);
	}
	else {
		System.out.println("else");
		out.println("<b>Incorect answer!!!!!!! Enter correct answer and try again<b>");
			
			  dispatcher = request.getRequestDispatcher("forgotPassword.html");
			  dispatcher.include(request, response);
			 
		//response.sendRedirect("ForgotPassword");
	}
	}
		
}
