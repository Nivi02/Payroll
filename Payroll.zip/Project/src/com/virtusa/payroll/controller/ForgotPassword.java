package com.virtusa.payroll.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.virtusa.payroll.dao.LoginDAO;


@WebServlet("/ForgotPassword")
public class ForgotPassword extends HttpServlet {
	private static final long serialVersionUID = 1L;
		
	 
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		String emid= request.getParameter("eid");
		int empid = Integer.parseInt(emid);
		System.out.println(empid+"dfddfdg");
		HttpSession session=request.getSession();
		session.setAttribute("eid",empid );

		
		out.println("<!DOCTYPE html>");
		out.print("<html>");
		out.println("<style>");     
		  out.println("#content {");       
		  out.println("position: absolute;  ");
		  out.println("top: 50%;  ");
		  out.println("transform: translate(-50%, -50%) ;");
		  out.println("  left: 50%; ");
		  out.println("}");
		  out.println("</style>");    
		 out.println("<body background='i1.jpg' style='background-size:cover;'><div id='content'><form action='Validate' method='post'><pre>");
		 out.println("Answer this question to change password :"+"<br><br>");
		 String questioninDB=LoginDAO.getQuestion(empid);
		 out.println("<b>"+questioninDB+"</b><br><br>");
		 out.println("<input type='text' name='ans' required/><br><br>");
		 out.println("<input type='submit' value='Submit answer' />");
		 out.print("</pre></form></div></body>");
	}
}
