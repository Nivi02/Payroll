package com.virtusa.payroll.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.virtusa.payroll.dao.LoginDAO;

/**
 * Servlet implementation class Password
 */
@WebServlet("/Password")
public class Password extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();                                      
			 
		HttpSession session=request.getSession(false);
		int empid=(int) session.getAttribute("eid");
		//int empid=1;
		String newPassword=request.getParameter("new");
		System.out.println(newPassword);
		String confirmPassword=request.getParameter("confirm");	
		System.out.println(confirmPassword);
		 RequestDispatcher dispatcher = null;
		String result = LoginDAO.update(empid, newPassword, confirmPassword);
		System.out.println("2"+result);
		       if(result.isEmpty()) {
		         out.println("Password changed successfully");
		        dispatcher = request.getRequestDispatcher("login.html");
		        dispatcher.include(request, response);
		        }
	    	  else  {
	    			  out.println(result);
	    			  dispatcher = request.getRequestDispatcher("password.html");
	  		          dispatcher.include(request, response);
	    		  }
		}
		

}
