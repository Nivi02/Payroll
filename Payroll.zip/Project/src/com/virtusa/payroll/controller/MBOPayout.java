package com.virtusa.payroll.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.virtusa.payroll.dao.MBODAO;



/**
 * Servlet implementation class MBOPayout
 */
@WebServlet("/MBOPayout")
public class MBOPayout extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		RequestDispatcher dispatcher = null;
		HttpSession session = request.getSession(false);
		int eid = (int) session.getAttribute("eid");
		String y = request.getParameter("year");
		int year = Integer.parseInt(y);
		String quarter = request.getParameter("mbo");
		float mbopayout=MBODAO.getMBO(year, quarter, eid);
		
		if(mbopayout>0) {
			out.println("MBO Payout for "+quarter+" "+year+" is ");
			out.println(mbopayout);
			dispatcher = request.getRequestDispatcher("Mbo");
			dispatcher.include(request, response);

		}
		else {
			out.println("Invalid Selection!!!!!!! Select correct details");
			dispatcher = request.getRequestDispatcher("Mbo");
			dispatcher.include(request, response);
		}
		
	}
	}


