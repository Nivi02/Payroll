package com.virtusa.payroll.testing;

import org.junit.Assert;
import org.junit.Test;

import com.virtusa.payroll.dao.LoginDAO;
import com.virtusa.payroll.models.Login;
public class ChangePasswordTest {
	@Test
	public void checkOldPassword() {
	String passwordByUser = "Abi@02";
	Login l = LoginDAO.login2(2);
	System.out.println(l.getPassword()+"  "+passwordByUser);
	Assert.assertEquals(l.getPassword(), passwordByUser);
}


}