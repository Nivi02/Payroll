package com.virtusa.payroll.models;

public class Employee {
	String empname;
	String email_id;
	String contact_number;
	float experience;

	
	  public Employee() { 
		  
	  }
	 
	public Employee(String empname, String email_id, String contact_number, float experience) {
		this.empname = empname;
		this.email_id = email_id;
		this.contact_number = contact_number;
		this.experience = experience;
	}
	public String getEmpname() {
		return empname;
	}
	public void setEmpname(String empname) {
		this.empname = empname;
	}
	public String getEmail_id() {
		return email_id;
	}
	public void setEmail_id(String email_id) {
		this.email_id = email_id;
	}
	public String getContact_number() {
		return contact_number;
	}
	public void setContact_number(String contact_number) {
		this.contact_number = contact_number;
	}
	public float getExperience() {
		return experience;
	}
	public void setExperience(float experience) {
		this.experience = experience;
	}
	
	@Override
	public String toString() {
		return "Employee [empname=" + empname + ", email_id=" + email_id + ", contact_number=" + contact_number
				+ ", experience=" + experience + "]";
	}
}
