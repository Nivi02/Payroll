package com.virtusa.payroll.models;

public class Login {
	int name;
	String password;
	public int getName() {
		return name;
	}
	public void setName(int name) {
		this.name = name;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public Login(int name, String password) {
		super();
		this.name = name;
		this.password = password;
	}
	@Override
	public String toString() {
		return "Login [name=" + name + ", password=" + password + "]";
	}
	

}
